package com.example.task_01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
