// validators.dart

// Class containing static methods for validating form fields
class Validators {
  
  // Validate Name field: should not be empty and only contain letters
  static String? validateName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your name'; // Error message if empty
    }
    if (!RegExp(r'^[a-zA-Z]+$').hasMatch(value)) {
      return 'Name should contain only letters'; // Error if non-alphabet characters are included
    }
    return null; // No error
  }

  // Validate Email field: checks if it's in a valid email format
  static String? validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email'; // Error if empty
    }
    if (!RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$').hasMatch(value)) {
      return 'Enter a valid email address'; // Error if format is incorrect
    }
    return null; // No error
  }

  // Validate CNIC field: must be exactly 13 digits
  static String? validateCnic(String? value) {
    if (value == null || value.length != 13) {
      return 'CNIC must be exactly 13 digits'; // Error if length is not 13
    }
    return null; // No error
  }

  // Validate Contact Number field: should be between 10 and 12 digits
  static String? validateContactNumber(String? value) {
    if (value == null || value.length < 10 || value.length > 12) {
      return 'Contact number should be 10-12 digits'; // Error if length is outside range
    }
    return null; // No error
  }

  // Validate Address field: should not be empty
  static String? validateAddress(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your address'; // Error if empty
    }
    return null; // No error
  }

  // Validate Password field: should be at least 8 characters, containing letters, numbers, and symbols
  static String? validatePassword(String? value) {
    if (value == null || value.length < 8) {
      return 'Password must be at least 8 characters'; // Error if too short
    }
    if (!RegExp(r'^(?=.*?[A-Za-z])(?=.*?[0-9])(?=.*?[!@#\$&*~])').hasMatch(value)) {
      return 'Password must contain letters, numbers, and symbols'; // Error if criteria not met
    }
    return null; // No error
  }
}
