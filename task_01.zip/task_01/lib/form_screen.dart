import 'package:flutter/material.dart';
import 'custom_text_form_field.dart';
import 'validators.dart'; // Import the validators to handle form field validation

class FormScreen extends StatefulWidget {
  @override
  _FormScreenState createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
  final _formKey = GlobalKey<FormState>(); // Key to manage the form state

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Form'), 
        backgroundColor: Colors.blueAccent, 
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0), 
        child: Form(
          key: _formKey, // Form key to track the form state
          child: ListView(
            children: [
              // Custom text form field for name
              CustomTextFormField(
                label: 'Name',
                icon: Icons.person,
                validator: Validators.validateName, // Validator function for name
              ),
              // Custom text form field for email
              CustomTextFormField(
                label: 'Email',
                icon: Icons.email, 
                validator: Validators.validateEmail, // Validator function for email
              ),
              // Custom text form field for CNIC
              CustomTextFormField(
                label: 'CNIC',
                icon: Icons.perm_identity, 
                validator: Validators.validateCnic, // Validator function for CNIC
              ),
              // Custom text form field for contact number
              CustomTextFormField(
                label: 'Contact Number',
                icon: Icons.phone, 
                validator: Validators.validateContactNumber, // Validator function for contact number
              ),
              // Custom text form field for address
              CustomTextFormField(
                label: 'Address',
                icon: Icons.location_on, 
                validator: Validators.validateAddress, // Validator function for address
              ),
              // Custom text form field for password
              CustomTextFormField(
                label: 'Password',
                icon: Icons.lock, 
                obscureText: true, // Make the text field obscure (for password input)
                validator: Validators.validatePassword, // Validator function for password
              ),
              SizedBox(height: 20), // Spacer between fields and submit button
              // Submit button
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) { // Validate the form
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Form is valid!')), // Show a confirmation message if form is valid
                    );
                  }
                },
                child: Text('Submit', style: TextStyle(fontSize: 18)), 
              ),
            ],
          ),
        ),
      ),
    );
  }
}
