import 'package:flutter/material.dart';

class CustomTextFormField extends StatelessWidget {
  final String label; 
  final IconData icon; // Icon displayed inside the text field
  final bool obscureText; 
  final String? Function(String?)? validator; // Validation function for the field

  // Constructor to initialize the values
  CustomTextFormField({
    required this.label,
    required this.icon,
    this.obscureText = false, // Default value for obscureText is false
    this.validator, // Validator function passed as an argument
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0), 
      child: TextFormField(
        obscureText: obscureText, // Use obscureText for password fields
        decoration: InputDecoration(
          labelText: label, 
          prefixIcon: Icon(icon), 
          border: OutlineInputBorder(), // Border style for the text field
        ),
        validator: validator, // Assign the validator for the text field
      ),
    );
  }
}
