import 'package:flutter/material.dart';
import 'form_screen.dart'; // Import the form screen which contains the form widget

// Main function to run the app
void main() {
  runApp(MyApp());
}

// MyApp widget is the root widget of the application
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Return the MaterialApp widget which sets up the theme and home screen
    return MaterialApp(
      title: 'Form Validation Demo', // Title of the app
      theme: ThemeData(
        primarySwatch: Colors.blue, // App theme with blue primary color
      ),
      home: FormScreen(), // Set FormScreen as the starting screen of the app
    );
  }
}
