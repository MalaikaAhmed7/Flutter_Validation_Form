# Task 01 - User Form with Validation

This Flutter project demonstrates a user registration form with validation. It includes fields such as Name, Email, CNIC, Contact Number, Address, and Password. Each field has validation rules to ensure the user enters correct information before submitting.

# Features:
- Name: Only letters allowed.
- Email: Valid email format required.
- CNIC: Exactly 13 digits.
- Contact Number: Between 10 and 12 digits.
- Address: Must not be empty.
- Password: At least 8 characters, with letters, numbers, and symbols.

# Getting Started

To run the project, follow these steps:

1. Clone this repository.
2. Install dependencies by running `flutter pub get`.
3. Run the app using `flutter run`.

## Resources
- [Flutter Official Documentation](https://flutter.dev/docs)
- [Flutter Cookbook](https://flutter.dev/docs/cookbook)